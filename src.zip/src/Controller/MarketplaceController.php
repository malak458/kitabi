<?php

namespace App\Controller;

use App\Repository\BookRepository;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class MarketplaceController extends AbstractController
{
    #[Route('/marketplace', name: 'app_marketplace')]
    public function index(
        Request $request,
        BookRepository $bookRepository,
        PaginatorInterface $paginator
    ): Response {

        $search = $request->query->get('search', '');
        $genre = $request->query->get('genre', '');
        $condition = $request->query->get('condition', '');
        $sort = $request->query->get('sort', 'newest');

        $queryBuilder = $bookRepository->findFilteredQuery(
            $search,
            $genre,
            $condition,
            $sort
        );

        $books = $paginator->paginate(
            $queryBuilder,
            $request->query->getInt('page', 1),
            8
        );

        return $this->render('marketplace/index.html.twig', [

            'books' => $books,

            'filters' => [
                'search' => $search,
                'genre' => $genre,
                'condition' => $condition,
                'sort' => $sort,
            ],

            'genres' => [
                'Fiction',
                'Fantasy',
                'Romance',
                'Mystery',
                'Thriller',
                'History',
                'Biography',
                'Science Fiction',
                'Classic Literature'
            ],

            'conditions' => [
                'Like new',
                'Good',
                'Fair',
                'Acceptable'
            ]
        ]);
    }
}